namespace ChatupNET.Database
{
    /// <summary>
    ///
    /// </summary>
    internal enum Comparison
    {
        Equals,
        NotEquals,
        Like,
        NotLike,
        GreaterThan,
        GreaterOrEquals,
        LessThan,
        LessOrEquals,
        In
    }

    /// <summary>
    ///
    /// </summary>
    internal enum LogicOperator
    {
        And,
        Or
    }
}