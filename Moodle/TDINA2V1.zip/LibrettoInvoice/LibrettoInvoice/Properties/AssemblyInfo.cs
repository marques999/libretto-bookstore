﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("LibrettoInvoice")]
[assembly: AssemblyCompany("FEUP")]
[assembly: AssemblyProduct("LibrettoInvoice")]
[assembly: ComVisible(false)]
[assembly: Guid("497bdf60-7c4f-4e84-bb86-077130232b78")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]