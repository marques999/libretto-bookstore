﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("LibrettoCommon")]
[assembly: AssemblyCompany("FEUP")]
[assembly: AssemblyProduct("LibrettoCommon")]
[assembly: ComVisible(false)]
[assembly: Guid("cf64510b-78ec-4d27-badf-65d9c392c7bb")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]