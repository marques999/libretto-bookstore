﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("LibrettoClient")]
[assembly: AssemblyCompany("FEUP")]
[assembly: AssemblyProduct("LibrettoClient")]
[assembly: ComVisible(false)]
[assembly: Guid("cea1bdb5-41d4-4005-b565-9595eafd6bde")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]