﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("WarehouseClient")]
[assembly: AssemblyProduct("WarehouseClient")]
[assembly: ComVisible(false)]
[assembly: Guid("ba413d43-08fc-4678-b1f0-230862e12468")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]