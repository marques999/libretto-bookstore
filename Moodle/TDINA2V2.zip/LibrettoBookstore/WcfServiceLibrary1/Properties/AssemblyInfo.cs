﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("LibrettoServer")]
[assembly: AssemblyProduct("LibrettoServer")]
[assembly: ComVisible(false)]
[assembly: Guid("e2481f58-9bb4-45b4-be0a-34587ee0aa1e")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]