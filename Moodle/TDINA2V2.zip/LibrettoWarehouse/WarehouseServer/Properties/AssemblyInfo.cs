﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("WarehouseServer")]
[assembly: AssemblyProduct("WarehouseServer")]
[assembly: ComVisible(false)]
[assembly: Guid("7318915b-6652-4e37-bb84-121d160a8216")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]